\# Propuesta Técnica – Pipeline de MLOps y Servicio Médico con Docker



\---



\# 1. Contexto del problema



Dados los avances tecnológicos en medicina y la gran cantidad de información clínica existente, es posible desarrollar soluciones capaces de apoyar la clasificación preliminar de pacientes a partir de síntomas y variables médicas básicas.



La solución propuesta simula el comportamiento de un sistema de predicción médica que, a partir de síntomas y variables clínicas básicas del paciente, permite estimar el posible estado de salud del paciente.



Aunque para esta actividad no es necesario entrenar un modelo real de Machine Learning, la arquitectura propuesta queda preparada para futuras integraciones con modelos entrenados tanto para enfermedades comunes como enfermedades huérfanas.



\---



\# 2. Objetivo de la solución



Diseñar un pipeline general de MLOps y una solución contenerizada con Docker que permita ejecutar un servicio médico simple, portable, escalable y fácil de desplegar.



El sistema permitirá a un médico ingresar datos clínicos básicos de un paciente y obtener una clasificación automática del estado del paciente.



\---



\# 3. Estados posibles del sistema



El sistema puede retornar uno de los siguientes estados:



\- NO ENFERMO

\- ENFERMEDAD LEVE

\- ENFERMEDAD AGUDA

\- ENFERMEDAD CRÓNICA



\---



\# 4. Pipeline General de MLOps



El pipeline propuesto está compuesto por las siguientes etapas:



1\. Recolección de datos

2\. Validación de datos

3\. Procesamiento de información

4\. Simulación del modelo de predicción

5\. Generación de respuesta

6\. Exposición del servicio web

7\. Contenerización con Docker

8\. Despliegue local

9\. Monitoreo y mejoras futuras



\---



\# 5. Diagrama General del Pipeline



```text

┌──────────────────────┐

│       MÉDICO         │

│ Ingresa información  │

└──────────┬───────────┘

&#x20;          │

&#x20;          ▼

┌──────────────────────┐

│ FORMULARIO WEB/API   │

│ Recepción de datos   │

└──────────┬───────────┘

&#x20;          │

&#x20;          ▼

┌──────────────────────┐

│ VALIDACIÓN DE DATOS  │

│ Verifica entradas    │

└──────────┬───────────┘

&#x20;          │

&#x20;          ▼

┌──────────────────────┐

│ FUNCIÓN DEL MODELO   │

│ Simulación predictiva│

└──────────┬───────────┘

&#x20;          │

&#x20;          ▼

┌──────────────────────┐

│ RESULTADO MÉDICO     │

│ Clasificación final  │

└──────────┬───────────┘

&#x20;          │

&#x20;          ▼

┌──────────────────────┐

│ CONTENEDOR DOCKER    │

│ Despliegue portable  │

└──────────────────────┘

```



\---



\# 6. Explicación de las etapas



\## 6.1 Recolección de datos



El médico ingresa información básica del paciente mediante un formulario web.



Las variables utilizadas son:



\- Temperatura corporal

\- Frecuencia cardíaca

\- Nivel de oxígeno



\---



\## 6.2 Validación de datos



El sistema valida que:



\- Los campos no estén vacíos.

\- Los valores sean numéricos.

\- Los datos estén dentro de rangos razonables.



\---



\## 6.3 Procesamiento de información



La información ingresada es enviada a la función principal del modelo.



\---



\## 6.4 Simulación del modelo de predicción



La solución implementa una función que simula el comportamiento de un modelo de clasificación médica.



La lógica utiliza reglas condicionales simples para determinar el estado del paciente.



Ejemplo:



\- Temperatura normal + oxígeno normal → NO ENFERMO

\- Temperatura alta + oxígeno bajo → ENFERMEDAD AGUDA



\---



\# 7. Función propuesta para simular el modelo



La función propuesta cumple con los requisitos definidos en la actividad:



\- Recibe mínimo 3 parámetros.

\- Evalúa diferentes condiciones.

\- Retorna uno de los 4 estados solicitados.

\- Simula un modelo de predicción médica.

\- Permite futuras mejoras.



Las variables utilizadas son:



| Variable | Descripción |

|---|---|

| temperatura | Temperatura corporal |

| frecuencia\_cardiaca | Pulsaciones por minuto |

| oxigeno | Saturación de oxígeno |



\---



\# 8. Exposición del servicio



El sistema expone el modelo mediante una aplicación web desarrollada en Flask.



La solución permite:



\- Ingresar datos clínicos.

\- Ejecutar la predicción.

\- Visualizar el resultado.

\- Consumir el servicio vía API REST.



\---



\# 9. Contenerización con Docker



Toda la solución se ejecuta dentro de un contenedor Docker.



Esto permite:



\- Facilidad de despliegue.

\- Portabilidad.

\- Compatibilidad multiplataforma.

\- Ejecución consistente.

\- Escalabilidad futura.



\---



\# 10. Dockerfile utilizado



El Dockerfile realiza las siguientes funciones:



\- Define una imagen base de Python.

\- Configura el entorno de trabajo.

\- Instala dependencias.

\- Copia los archivos necesarios.

\- Expone el puerto del servicio.

\- Ejecuta automáticamente la aplicación.



\---



\# 11. Arquitectura propuesta



La arquitectura del proyecto está dividida en:



| Componente | Función |

|---|---|

| modelo.py | Lógica del modelo |

| app.py | Aplicación web/API |

| Dockerfile | Construcción de imagen |

| requirements.txt | Dependencias |

| README.md | Documentación |

| propuesta\_tecnica.md | Explicación del pipeline |



\---



\# 12. Viabilidad de la solución



La propuesta es viable porque utiliza una arquitectura simple, modular y portable.



La solución permite separar:



\- La lógica del modelo.

\- La interfaz de usuario.

\- La exposición del servicio.

\- La contenerización.



Esto facilita futuras mejoras e integración con modelos reales de inteligencia artificial.



\---



\# 13. Consideraciones de diseño



\## Restricciones y limitaciones



La solución desarrollada corresponde a una simulación académica y presenta las siguientes limitaciones:



\- No utiliza datos clínicos reales.

\- No implementa un modelo real de Machine Learning entrenado.

\- No realiza almacenamiento persistente de información.

\- No incluye autenticación de usuarios.

\- No cuenta con monitoreo automático de desempeño.



Sin embargo, la arquitectura fue diseñada para permitir futuras mejoras e integración con modelos reales.



\---



\## Tipos de datos utilizados



La solución trabaja con variables clínicas numéricas básicas:



| Variable | Tipo |

|---|---|

| temperatura | Numérico |

| frecuencia\_cardiaca | Numérico |

| oxigeno | Numérico |



En una implementación real podrían utilizarse:



\- Historial clínico.

\- Síntomas reportados.

\- Exámenes médicos.

\- Imágenes diagnósticas.

\- Datos de laboratorio.



\---



\# 14. Consideraciones de desarrollo



\## Fuentes de datos



En esta actividad los datos son ingresados manualmente mediante un formulario web.



En un escenario real, los datos podrían provenir de:



\- Historias clínicas.

\- Bases de datos hospitalarias.

\- Dispositivos médicos.

\- APIs de salud.

\- Sistemas de información hospitalaria.



\---



\## Manejo de datos



Los datos ingresados son procesados temporalmente durante la ejecución de la aplicación.



No se realiza almacenamiento permanente de información clínica.



\---



\## Tipos de modelos de ML que podrían utilizarse



En una solución real podrían utilizarse modelos como:



\- Árboles de decisión.

\- Random Forest.

\- Redes neuronales.

\- XGBoost.

\- Modelos de Deep Learning.

\- Modelos especializados para datos médicos.



Para enfermedades huérfanas podrían aplicarse técnicas como:



\- Transfer Learning.

\- Few-Shot Learning.

\- Data Augmentation.



\---



\## Validación y pruebas



La solución fue validada mediante:



\- Pruebas manuales desde navegador.

\- Consumo del endpoint API.

\- Ejecución del contenedor Docker.

\- Validación de respuestas esperadas.



En una solución real podrían aplicarse:



\- Train/Test Split.

\- Cross Validation.

\- Métricas de precisión.

\- Sensibilidad y especificidad.



\---



\# 15. Consideraciones de producción



\## Despliegue de la solución



La solución se despliega mediante Docker, permitiendo:



\- Portabilidad.

\- Fácil instalación.

\- Compatibilidad multiplataforma.

\- Despliegue local o en servidor.



\---



\## Monitoreo



En una implementación futura podrían monitorearse:



\- Tiempo de respuesta.

\- Uso del servicio.

\- Errores de predicción.

\- Disponibilidad de la aplicación.



\---



\## Reentrenamiento del modelo



En una solución real podrían aparecer nuevos datos clínicos que permitan:



\- Mejorar el modelo.

\- Reentrenar algoritmos.

\- Ajustar reglas de clasificación.

\- Incorporar nuevas enfermedades.



Esto permitiría mantener actualizado el sistema predictivo.



\---



\# 16. Posibles mejoras futuras



La solución puede evolucionar hacia:



\- Modelos reales de Machine Learning.

\- Integración con bases de datos médicas.

\- Registro histórico de predicciones.

\- Monitoreo de desempeño.

\- Reentrenamiento automático.

\- Integración con servicios cloud.

\- Autenticación de usuarios médicos.



\## Consideración sobre enfermedades huérfanas



La solución desarrollada para esta actividad utiliza una simulación basada en reglas y no un modelo real entrenado con datos clínicos.



Sin embargo, la arquitectura propuesta queda preparada para futuras integraciones con modelos de Machine Learning especializados en escenarios con:



\- Grandes volúmenes de datos (enfermedades comunes).

\- Pocos datos disponibles (enfermedades huérfanas).



En un escenario real, podrían utilizarse técnicas como:



\- Transfer Learning.

\- Few-Shot Learning.

\- Data Augmentation.

\- Modelos preentrenados.

\- Aprendizaje semi-supervisado.



Estas técnicas permiten construir modelos capaces de trabajar incluso cuando la cantidad de información disponible es reducida.



\---



\# 17. Conclusión



La solución desarrollada cumple con los requisitos solicitados para el pipeline de MLOps y la construcción de una imagen Docker personalizada.



El sistema permite simular un modelo de predicción médica, exponerlo mediante una aplicación web y ejecutarlo de forma portable utilizando Docker.



Aunque el modelo utilizado es una simulación mediante reglas básicas, la arquitectura propuesta queda preparada para futuras integraciones con modelos reales de Machine Learning.

